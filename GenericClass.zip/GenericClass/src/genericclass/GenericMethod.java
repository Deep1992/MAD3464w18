/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package genericclass;

/**
 *
 * @author macstudent
 */
public class GenericMethod {
    // generic method printArray
    public static <E> void printArray(E[] inputArray){
        // display array element
        for(E element : inputArray) {
            System.out.printf("%s", element);
        }
        System.out.println();
        
        }
    public static void main(String Args[]){
        //create array of integer, Double and Character
        Integer[] intArray = {1,2,3,4,5};
        Double[] doubleArray = {1.1,2.2,3.3,4.4};
        Character[] charArray = {'h','e','l','l','o'};
        
        System.out.println("Array integerArray contains:");
        printArray(intArray);//pass an integer array
        
        System.out.println("\nArray doubleArray contains:");
        printArray(intArray);
         System.out.println("\nArray CharacterArray contains:");
          printArray(charArray);
    }
    
}
